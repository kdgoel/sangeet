import 'package:flutter/material.dart';
import 'package:sangeet2/screens/homePage.dart';
import 'package:sangeet2/screens/homeScreen.dart';
import 'package:sangeet2/services/loading_screens.dart';

void main() => runApp(
      MaterialApp(
        theme: ThemeData.dark(),
        // home: LoadingScreen(),
        initialRoute: "/",
        routes: {
          '/': (context) => const LoadingScreen(),
          '/home': (context) => Home(),
          '/home2': (context) => const HomePage2(),
        },
      ),
    );
